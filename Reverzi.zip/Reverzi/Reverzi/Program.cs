﻿namespace Reverzi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Tabla ujTabla = new Tabla("allas.txt");
            //5. feladat:
            Console.WriteLine("5.feladat: ");
            ujTabla.Megjelenit();
            //6. feladat:
            Console.WriteLine("6. feladat: ");
            Console.WriteLine("\tKék korongok száma:" + ujTabla.MezoSzama('K'));
            Console.WriteLine("\tFehér korongok száma:" + ujTabla.MezoSzama('F'));
            Console.WriteLine("\tÜres korongok száma:" + ujTabla.MezoSzama('#'));
            //8. feladat: 
            string parameterek = "F;4;1;0;1";
            Console.WriteLine($"8.feladat: " + $"[jatekos;sor;oszlop;iranySor;iranyOszlop] = {parameterek}");

            string[] elemek = parameterek.Split(';');
            var j = char.Parse(elemek[0]);
            var s = byte.Parse(elemek[1]);
            var o = byte.Parse(elemek[2]);
            var iS = byte.Parse(elemek[3]);
            var iO = byte.Parse(elemek[4]);
            if (ujTabla.VanForditas(j,s,o,iS,iO))
            {
                Console.WriteLine("Van fordítás!");
            }
            else
            {
                Console.WriteLine("Nincs fordítás! :(");
            }

        }
    }
}